﻿using System;

namespace Pierwiastki_rownania_18
{
    class Program
    {
        static double ObliczDelte(double a, double b, double c)
        {
            return Math.Pow(b, 2) - 4 * a * c;
        }
        static double ObliczX1(double delta, double a, double b)
        {
            return (-Math.Sqrt(delta) - b) / (2 * a);
        }
        static double ObliczX2(double delta, double a, double b)
        {
            return (Math.Sqrt(delta) - b) / (2 * a);
        }
        static double ObliczX0(double b, double a)
        {
            return -b / (2 * a);
        }
        static void Main(string[] args)
        {
            double a = 1;
            double b = 10;
            double c = 4;
            if (ObliczDelte(a,b,c)>0)
            {
                Console.WriteLine("X1:" + ObliczX1(ObliczDelte(a, b, c), a, b));
                Console.WriteLine("X2:" + ObliczX2(ObliczDelte(a, b, c), a, b));
            }
            else if(ObliczDelte(a,b,c)==0)
            {
                Console.WriteLine("X0:" +  ObliczX0(a, b));
            }
            else
            {
                Console.WriteLine("Niema pierwiastków");
            }
        }
    }
}
