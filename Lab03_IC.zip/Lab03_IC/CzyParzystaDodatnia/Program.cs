﻿using System;

namespace CzyParzystaDodatnia
{
    class Program
    {
        static bool CzyParzystaIDodatnia(int x)
        {
            return (x % 2 == 0 && x > 0);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyParzystaIDodatnia(10));
        }
    }
}
