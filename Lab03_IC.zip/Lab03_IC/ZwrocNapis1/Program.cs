﻿using System;

namespace ZwrocNapis1
{
    class Program
    {
        static string ZwrocNapis1(string tekst, char znak)
        {
            if(tekst.Length % 2 != 0)
            {
                return tekst + znak;
            }
            else
            {
                return znak.ToString();
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocNapis1("dziecko",'r'));
        }
    }
}
