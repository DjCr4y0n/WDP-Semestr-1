﻿using System;

namespace IlePierwiastkow
{
    class Program
    {
        static int IlePierwiastkow(double delta)
        {
            if(delta>0)
            {
                return 2;
            }
            else if(delta==0)
            {
                return 1;
            }
            return 0;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(IlePierwiastkow(-20));
        }
    }
}
