﻿using System;

namespace CzyDodatnia
{
    class Program
    {

        static bool CzyDodatnia(double x)
        {
            if(x>=0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyDodatnia(-24.5));
        }
    }
}
