﻿using System;

namespace CzyTakieSame
{
    class Program
    {
        static bool CzyTakieSame(string tekst1, string tekst2)
        {
            return (tekst1 == tekst2);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyTakieSame("Witam","Witam"));
        }
    }
}
