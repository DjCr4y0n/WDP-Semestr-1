﻿using System;

namespace CzyParzysta
{
    class Program
    {
        static bool CzyParzysta(int liczba)
        {
            if(liczba % 2 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyParzysta(11));
        }
    }
}
