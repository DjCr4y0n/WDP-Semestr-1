﻿using System;

namespace PodzielPizze
{
    class Program
    {
        static double PodzielPizze(int a, int b)
        {
            if (b == 0)
                throw new Exception("Próba dzielenia przez zero!");
            return (double) a / b;
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(PodzielPizze(2, 0));
                
            }
            catch (Exception w)
            {

                Console.WriteLine(w.Message);
            }
        }
    }
}
