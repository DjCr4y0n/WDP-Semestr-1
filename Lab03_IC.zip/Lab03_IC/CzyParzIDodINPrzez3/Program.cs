﻿using System;

namespace CzyParzIDodINPrzez3
{
    class Program
    {

        static bool CzyParzIDodINPrzez3(int a)
        {
            return (a % 2 == 0 && a > 0 && a % 3 != 0);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyParzIDodINPrzez3(-10));
        }
    }
}
