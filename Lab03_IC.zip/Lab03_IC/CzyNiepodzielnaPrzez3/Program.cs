﻿using System;

namespace CzyNiepodzielnaPrzez3
{
    class Program
    {
        static bool CzyNiepodzielnaPrzez3(int x)
        {
            return (x % 3 != 0);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyNiepodzielnaPrzez3(9));
        }
    }
}
