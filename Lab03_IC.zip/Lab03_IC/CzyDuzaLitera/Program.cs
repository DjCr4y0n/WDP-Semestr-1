﻿using System;

namespace CzyDuzaLitera
{
    class Program
    {
        static bool CzyDuzaLitera(char znak)
        {
            return (znak >= 'A' && znak <= 'Z');
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyDuzaLitera('h'));
        }
    }
}
