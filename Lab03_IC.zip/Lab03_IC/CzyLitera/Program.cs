﻿using System;

namespace CzyLitera
{
    class Program
    {
        static bool CzyMalaLitera(char znak)
        {
            return (znak >= 'a' && znak <= 'z');
        }
        static bool CzyDuzaLitera(char znak)
        {
            return (znak >= 'A' && znak <= 'Z');
        }
        static bool CzyLitera(char znak)
        {
            return (CzyMalaLitera(znak) || CzyDuzaLitera(znak));
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyLitera(';'));
        }
    }
}
