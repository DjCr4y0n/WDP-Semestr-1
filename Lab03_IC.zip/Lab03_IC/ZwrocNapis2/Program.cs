﻿using System;

namespace ZwrocNapis2
{
    class Program
    {
        static string ZwrocNapis2(string tekst1, string tekst2)
        {
            if(tekst2.Length < tekst1.Length/2)
            {
                return tekst1 + tekst2;
            }
            else
            {
                return tekst1;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocNapis2("babcia","dziadek"));
        }
    }
}
