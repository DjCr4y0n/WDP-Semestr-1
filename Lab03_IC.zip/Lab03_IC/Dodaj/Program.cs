﻿using System;

namespace Dodaj
{
    class Program
    {
        static long Dodaj(long a, long b)
        {
            return checked(a + b);
        }
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine(Dodaj(9223372036854775807, 2));
            }
            catch (OverflowException)
            {
                Console.WriteLine("Uwaga! Nastąpiło przepełnienie zmiennej!");
            }
        }
    }
}
