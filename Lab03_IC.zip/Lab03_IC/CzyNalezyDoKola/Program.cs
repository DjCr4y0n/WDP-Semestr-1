﻿using System;

namespace CzyNalezyDoKola
{
    class Program
    {
        static bool CzyNalezyDoKola(double X1, double Y1, double Xs, double Ys, double r)
        {
            return (Math.Sqrt(Math.Pow(X1 - Xs, 2) + Math.Pow(Y1 - Ys, 2)) <= r);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyNalezyDoKola(10,20,0,0,30));
        }
    }
}
