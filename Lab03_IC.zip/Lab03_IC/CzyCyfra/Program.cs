﻿using System;

namespace CzyCyfra
{
    class Program
    {
        static bool CzyCyfra(char znak)
        {
            return (znak >= '0' && znak <= '9');
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyCyfra(';'));
        }
    }
}
