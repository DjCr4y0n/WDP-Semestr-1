﻿using System;

namespace CzyMalaLitera
{
    class Program
    {
        static bool CzyMalaLitera(char znak)
        {
            return (znak >= 'a' &&  znak <= 'z');
        }
        static void Main(string[] args)
        {
            int a = (char) 'z';
            Console.WriteLine(CzyMalaLitera('A'));
        }
    }
}
