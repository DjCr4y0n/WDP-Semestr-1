﻿using System;

namespace CzyZero
{
    class Program
    {

        static bool CzyZero(int a)
        {
            if (a == 0)
            {
                return true; 
            }
            else
            {
                return false;
            }
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyZero(10));
        }
    }
}
