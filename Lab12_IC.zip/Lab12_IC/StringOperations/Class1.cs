﻿using System;

namespace StringOperations
{
    public class Napisy
    {
        public static string UsunZnaki(string tekst)
        {
            string nowy = "";
            for (int i = 0; i < tekst.Length; i++)
            {
                if ((tekst[i] >= 'a' && tekst[i] <= 'z') || (tekst[i] >= 'A' && tekst[i] <= 'Z'))
                {
                    nowy += tekst[i];
                }
            }
            return nowy;
        }
        public static string ZamienNaMale(string tekst)
        {
            string nowy = "";
            for (int i = 0; i < tekst.Length; i++)
            {
                if (tekst[i] > 'A' && tekst[i] < 'Z')
                {
                    int pom = (int)tekst[i] + 32;
                    nowy += (char)pom;
                }
                else
                {
                    nowy += tekst[i];
                }
            }
            return nowy;
        }

        public static bool CzyPalindromV1(string tekst)
        {
            for (int i = 0; i < tekst.Length; i++)
            {
                if (tekst[i] != tekst[tekst.Length - 1 - i])
                {
                    return false;
                }
            }
            return true;
        }

        static string Sortowanie(string input)
        {
            char[] tab = new char[input.Length];
            for(int i = 0; i<tab.Length;i++)
            {
                tab[i] = input[i];
            }

            int n = tab.Length;

            for (int i = 0; i < n - 1; i++)
                for (int j = 0; j < n - i - 1; j++)
                    if (tab[j] > tab[j + 1])
                    {
                        char temp = tab[j];
                        tab[j] = tab[j + 1];
                        tab[j + 1] = temp;
                    }
            return new string(tab);
        }


        public static bool CzyPlaindromV2(string tekst)
        {
            string pom = ZamienNaMale(UsunZnaki(tekst));
            return CzyPalindromV1(pom);
        }

        public static bool CzyAnagramV1(string tekst1, string tekst2)
        {
            if (Sortowanie(tekst1) == Sortowanie(tekst2)) return true;
            return false;

        }

        public static bool CzyAnagramV2(string tekst1, string tekst2)
        {
            string pom1 = ZamienNaMale(tekst1);
            string pom2 = ZamienNaMale(tekst2);
            if (Sortowanie(pom1) == Sortowanie(pom2)) return true;
            return false;
        }

        public static bool CzyAnagramV3(string tekst1, string tekst2)
        {
            string pom1 = UsunZnaki(tekst1);
            string pom2 = UsunZnaki(tekst2);
            if (Sortowanie(pom1) == Sortowanie(pom2)) return true;
            return false;
        }

        public static bool CzyJestParaV1(int[] tab)
        {
            int licznik = 0;
            for(int j=0; j<tab.Length;j++)
            {
                for (int i = 1; i < tab.Length; i++)
                {
                    if (tab[i] == tab[j]) licznik += 1;
                }
            }
            if (licznik == 1) return true;
            return false;
        }
        public static bool CzyJestParaV2(int[] tab)
        {
            for (int j = 0; j < tab.Length; j++)
            {
                for (int i = 1; i < tab.Length; i++)
                {
                    if (tab[i] == tab[j]) return true;
                }
            }
            return false;
        }

        public static bool CzyJestParaV3(int[] tab)
        {
            int licznik = 0;
            for (int j = 0; j < tab.Length; j++)
            {
                for (int i = 1; i < tab.Length; i++)
                {
                    if (tab[i] == tab[j]) licznik += 1;
                }
            }
            if (licznik >= 2) return true;
            return false;
        }

        public static bool CzyJestParaV4(int[] tab)
        {
            int licznik = 0;
            for (int j = 0; j < tab.Length; j++)
            {
                for (int i = 1; i < tab.Length; i++)
                {
                    if (tab[i] == tab[j]) licznik += 1;
                }
            }
            if (licznik == 2) return true;
            return false;
        }

    }
}
