﻿using System;
using StringOperations;

namespace Zadanie1
{


    class Program
    {
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 2, 2, 3, 4, 5, 2, 6, 1};
            int[] tab1 = { 1, 2, 2, 3, 4, 5, 6, 1 };
            Console.WriteLine(Napisy.UsunZnaki("Mama i OlA"));
            Console.WriteLine(Napisy.ZamienNaMale("SupER"));
            Console.WriteLine(Napisy.CzyPalindromV1("Kobyła - ma mały bok!"));
            Console.WriteLine(Napisy.CzyPlaindromV2("Kobyła - ma mały bok!"));
            Console.WriteLine(Napisy.CzyAnagramV1("Silent", "listen"));
            Console.WriteLine(Napisy.CzyAnagramV2("Silent", "listen"));
            Console.WriteLine(Napisy.CzyAnagramV3("silent#", "listen"));
            Console.WriteLine(Napisy.CzyJestParaV1(tab1));
            Console.WriteLine(Napisy.CzyJestParaV2(tab));
        }
    }
}
