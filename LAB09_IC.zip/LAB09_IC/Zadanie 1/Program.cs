﻿using System;

namespace Zadanie_1
{
    class Program
    {
        struct Kontakt
        {
            public string imię;
            public string nazwisko;
            public int numerTelefonu;
            public Kontakt(string _imię, string _nazwisko, int _numerTelefonu)
            {
                imię = _imię;
                nazwisko = _nazwisko;
                numerTelefonu = _numerTelefonu;
            }
        }
        static string ZwróćInformacje(Kontakt k)
        {
            return ($"{k.imię} {k.nazwisko} {k.numerTelefonu}");
        }

        static void Edytuj(ref Kontakt k)
        {
            Console.WriteLine("Czy chcesz edytować? [tak lub nie]");
            string odpowiedz = Console.ReadLine();
            if(odpowiedz == "tak")
            {
                Console.WriteLine("Podaj imię");
                string imię = Console.ReadLine();
                Console.WriteLine("Podaj nazwisko");
                string nazwisko = Console.ReadLine();
                Console.WriteLine("Podaj numer telefonu");
                string numerTelefonu = Console.ReadLine();

                k = new Kontakt(imię, nazwisko, Convert.ToInt32(numerTelefonu));

            }
        }

        struct BazaKontaktów
        {
            public Kontakt[] baza;
            public int licznik;
            public BazaKontaktów(int rozmiar)
            {
                baza = new Kontakt[rozmiar];
                licznik = 0;
            }
        }

        static void DodajDoBazy(ref BazaKontaktów bazaKontaktów, Kontakt k)
        {
            if(bazaKontaktów.licznik < bazaKontaktów.baza.Length)
            {
                bazaKontaktów.baza[bazaKontaktów.licznik] = k;
                bazaKontaktów.licznik += 1;
            }
            else
            {
                Kontakt[] tab = new Kontakt[bazaKontaktów.baza.Length + 1];
                for (int i = 0; i < bazaKontaktów.baza.Length; i++)
                {
                    tab[i] = bazaKontaktów.baza[i];
                }
                bazaKontaktów.baza = tab;

                bazaKontaktów.baza[bazaKontaktów.licznik] = k;
                bazaKontaktów.licznik++;
            }
        }

        static void WypiszBazę(BazaKontaktów bazaKontaktów)
        {
            for(int i =0; i<bazaKontaktów.baza.Length;i++)
            {
                Console.WriteLine($"Kontakt nr.{i + 1} {ZwróćInformacje(bazaKontaktów.baza[i])}");
            }
        }

        static void UsuńZBazy(ref BazaKontaktów bazaKontaktów, int i)
        {
            for (int x = i; x < bazaKontaktów.licznik - 1; x++)
            {
                bazaKontaktów.baza[x] = bazaKontaktów.baza[x + 1];
            }
            bazaKontaktów.licznik--;
        }

        static bool CzyIstniejeImie(BazaKontaktów bazaKontaktów, string imię)
        {
            for(int i=0;i<bazaKontaktów.baza.Length;i++)
            {
                if(bazaKontaktów.baza[i].imię==imię)
                {
                    return true;
                }
            }
            return false;
        }

        static bool CzyIstniejeNazwisko(BazaKontaktów bazaKontaktów, string nazwisko)
        {
            for (int i = 0; i < bazaKontaktów.baza.Length; i++)
            {
                if (bazaKontaktów.baza[i].nazwisko == nazwisko)
                {
                    return true;
                }
            }
            return false;
        }

        static bool CzyIstniejeNumer(BazaKontaktów bazaKontaktów, int numer)
        {
            for (int i = 0; i < bazaKontaktów.baza.Length; i++)
            {
                if (bazaKontaktów.baza[i].numerTelefonu == numer)
                {
                    return true;
                }
            }
            return false;
        }

        static int IleKontaktow(BazaKontaktów bazaKontaktów, string imię)
        {
            int licznik = 0;
            for (int i = 0; i < bazaKontaktów.baza.Length; i++)
            {
                if(bazaKontaktów.baza[i].imię == imię)
                {
                    licznik += 1;
                }
            }
            return licznik;
        }

        static BazaKontaktów Kopiuj(BazaKontaktów bazaKontaktów)
        {
            BazaKontaktów[] tab = new BazaKontaktów[bazaKontaktów.baza.Length];
            for(int i=0;i<bazaKontaktów.baza.Length;i++)
            {
                DodajDoBazy(ref tab, bazaKontaktów.baza[i]);
            }
            return tab;
        }

        static void Main(string[] args)
        {
            Kontakt k1;
            k1.imię = "Igor";
            k1.nazwisko = "Czarnogłowski";
            k1.numerTelefonu = 555333222;
            Console.WriteLine(ZwróćInformacje(k1));
            Edytuj(ref k1);
            Console.WriteLine(ZwróćInformacje(k1));
        }
    }
}
