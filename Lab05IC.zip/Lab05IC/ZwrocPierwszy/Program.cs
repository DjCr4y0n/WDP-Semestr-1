﻿using System;

namespace ZwrocPierwszy
{
    class Program
    {
        static int ZwrocPierwszy(int[] tab)
        {
            return tab[0];
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6 };
            Console.WriteLine(ZwrocPierwszy(array));
        }
    }
}

