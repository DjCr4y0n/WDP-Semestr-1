﻿using System;

namespace Srednia2
{
    class Program
    {
        static double Srednia2(int[] tab, int a, int b)
        {
            return (tab[a] + tab[b]) / 2;
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 4, 2, 432, 4, 5, 23, 3, 25, 32, 5, 23 };
            Console.WriteLine(Srednia2(array,2,7));
        }
    }
}
