﻿using System;

namespace SumaKwadratow
{
    class Program
    {
        static long SumaKwadratow(int[] tab1, int[] tab2)
        {
            return tab1[0] * tab1[0] + tab2[tab2.Length - 1] * tab2[tab2.Length - 1];
        }
        static void Main(string[] args)
        {
            int[] array1 = { 6, 2, 3, 4, 5, 6 };
            int[] array2 = { 1, 4, 5, 6, 4, 3, 2, 34, 5 };
            Console.WriteLine(SumaKwadratow(array1,array2));
        }
    }
}
