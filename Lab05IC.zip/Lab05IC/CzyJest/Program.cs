﻿using System;

namespace CzyJest
{
    class Program
    {
        static bool CzyJest(int[] T1, int a, int n = 0)
        {
            if (n == T1.Length)
                return false;
            if (T1[n] == a)
            {
                return true;
            }
            else
            {
                return CzyJest(T1, a, n+1);
            }
        }
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Console.WriteLine(CzyJest(tab,11));
        }
    }
}
