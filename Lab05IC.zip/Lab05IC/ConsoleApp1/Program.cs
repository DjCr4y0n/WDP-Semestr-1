﻿using System;

namespace ZwrocOstatni
{
    class Program
    {
        static int ZwrocOstatni(int[] tab)
        {
            int a = tab.Length - 1;
            return tab[a];
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6 };
            Console.WriteLine(ZwrocOstatni(array));
        }
    }
}

