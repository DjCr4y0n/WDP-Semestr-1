﻿using System;

namespace Suma
{
    class Program
    {
        static long Suma(int[] tab)
        {
            if (tab.Length == 0 || tab == null)
            {
                return 0;
            }
            return tab[0] + tab[tab.Length - 1];
        }
        static void Main(string[] args)
        {
            int[] array0 = { };
            int[] array = { 1, 2, 4, 5, 3, 66, 5, 4 };
            Console.WriteLine(Suma(array0));
        }
    }
}
