﻿using System;

namespace Srednia1
{
    class Program
    {
        static double Srednia1(int[] tab)
        {
            return (tab[0] + tab[tab.Length - 1]) / 2;
        }
        static void Main(string[] args)
        {
            int[] array = { 2, 3, 4, 5, 6 };
            Console.WriteLine(Srednia1(array));
        }
    }
}
