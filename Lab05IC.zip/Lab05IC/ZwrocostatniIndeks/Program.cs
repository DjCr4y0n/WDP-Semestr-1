﻿using System;

namespace ZwrocOstatniIndeks
{
    class Program
    {
        static int ZwrocOstatniIndeks(int[] tab)
        {
            return tab.Length-1;
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 3, 56, 6 };
            Console.WriteLine(ZwrocOstatniIndeks(array));
        }
    }
}
