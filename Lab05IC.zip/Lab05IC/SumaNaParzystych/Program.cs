﻿using System;

namespace SumaNaParzystych
{
    class Program
    {
        static int SumaNaParzystych(int[] T1, int n = 0)
        {
            if (n >= n)
            {
                return 0;
            }
            if (n%2==0)
            {
                return T1[0] + SumaNaParzystych(T1, n + 2);
            }
            else
            {
                //do dokonczenia
            }
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Console.WriteLine(SumaNaParzystych(array));
        }
    }
}
