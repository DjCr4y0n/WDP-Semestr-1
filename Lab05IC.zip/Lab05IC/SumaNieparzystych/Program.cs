﻿using System;

namespace SumaNieparzystych
{
    class Program
    {
        static long SumaNieparzystych(int[] T1, int n = 0)
        {
            if (T1[n] % 2 !=0)
            {
                long wynik = T1[n] + SumaNieparzystych(T1, n + 1);
                return wynik;
            }
            else
            {
                long wynik = SumaNieparzystych(T1,n+1);
                return wynik;
            }
            
        }
        static void Main(string[] args)
        {
            int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            Console.WriteLine(SumaNieparzystych(array));
        }
    }
}
