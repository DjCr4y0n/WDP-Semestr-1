﻿using System;

namespace Sprawdzanie_wartosci
{
    class Program
    {
        static int SprawdzWartosc(char znak)
        {
            int wynik = Convert.ToInt32(znak);
            return wynik;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SprawdzWartosc('x'));
        }
    }
}
