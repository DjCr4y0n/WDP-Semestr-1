﻿using System;

namespace Zwracanie_losowej_liczby
{
    class Program
    {
        static int ZwrocLosowaZPrzedzialu(int a, int b)
        {
            Random r = new Random();
            return r.Next(a,b+1);
        }

        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocLosowaZPrzedzialu(1,100));
        }
    }
}
