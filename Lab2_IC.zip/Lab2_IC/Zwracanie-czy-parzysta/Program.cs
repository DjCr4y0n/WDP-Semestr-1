﻿using System;

namespace Zwracanie_czy_parzysta
{
    class Program
    {
        static bool CzyParzysta(int a)
        {
            return ! Convert.ToBoolean(a % 2);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyParzysta(9));
        }
    }
}
