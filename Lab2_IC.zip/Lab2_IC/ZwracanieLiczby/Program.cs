﻿using System;

namespace ZwracanieLiczby
{
    class Program
    {

        static int ZwrocLiczbe()
        {
            return 5;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocLiczbe());
        }
    }
}
