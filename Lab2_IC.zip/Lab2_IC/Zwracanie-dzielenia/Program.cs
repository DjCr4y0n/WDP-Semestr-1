﻿using System;

namespace Zwracanie_dzielenia
{
    class Program
    {
        static double Podziel(int x, int y)
        {
            double wynik = (double)x / y;
            return wynik;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Podziel(10, 5));
        }
    }
}
