﻿using System;

namespace Funkcja_alternatywa
{
    class Program
    {
        static bool Alternatywa(int p, int q)
        {
            bool logiczna_p = Convert.ToBoolean(p);
            bool logiczna_q = Convert.ToBoolean(q);
            return logiczna_q || logiczna_p;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Alternatywa(10,2));
        }
    }
}
