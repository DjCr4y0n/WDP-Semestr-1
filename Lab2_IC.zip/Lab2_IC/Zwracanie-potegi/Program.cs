﻿using System;

namespace Zwracanie_potegi
{
    class Program
    {
        static int Potega(int a, int b)
        {
            return (int)(Math.Pow(a, b));
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Potega(2,3));
        }
    }
}
