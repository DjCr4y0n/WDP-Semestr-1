﻿using System;

namespace Ilość_znaków_w_tekście
{
    class Program
    {
        static int IleZnaków(string tekst1, string tekst2)
        {
            int wynik = tekst1.Length + tekst2.Length;
            return wynik;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(IleZnaków("witam","cześć"));
        }
    }
}
