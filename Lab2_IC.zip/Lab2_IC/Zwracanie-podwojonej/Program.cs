﻿using System;

namespace Zwracanie_podwojonej
{
    class Program
    {
        static int ZwrocPodwojona(int a)
        {
            return 2 * a;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocPodwojona(5));
        }
    }
}
