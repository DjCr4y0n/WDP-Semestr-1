﻿using System;

namespace Programy
{
    class Program
    {
        static string DoMalych(string napis)
        {
            string nowy = "";
            for (int i=0; i<napis.Length;i++)
            {
                int pom;
                if(napis[i] >= 'A' && napis[i] <='Z')
                {
                    pom = napis[i] + 32;
                    nowy += (char)pom;
                }
                else
                {
                    nowy += napis[i];
                }
            }
            return nowy; 
        }
        static bool CzyJest1(string napis)
        {
            int licznik = 0;
            string pom = DoMalych(napis);
            for(int i =0; i<napis.Length-1;i++)
            {
                if(pom[i+1] == 'a' || pom[i+1] == 'e' || pom[i+1] == 'i' || pom[i+1] == 'o' || pom[i+1] == 'u')
                {
                    if(pom[i] != 'a' || pom[i] != 'e' || pom[i] != 'i' || pom[i] != 'o' || pom[i] != 'u')
                    {
                        licznik += 1;
                    }
                }
            }
            if (licznik == 2)
            {
                return true;
            }
            else return false;
        }

        static bool CzyJest2(char x, char y, string napis)
        {
            int licznik = 0;
            string pom = DoMalych(napis);
            for(int i = 0; i<napis.Length-2;i++)
            { 
                if(pom[i] == x && pom[i+2]==y)
                {
                    licznik += 1;
                }
            }
            if (licznik == 2)
            {
                return true;
            }
            else return false;
        }

        static bool CzyPierwsza(int liczba)
        {
            if(liczba>=2)
            {
                for(int i=2;i<liczba;i++)
                {
                    if (liczba % i == 0) return false;
                }
                return true;
            }
            return false;
        }
        static int[] ZwrocTablice(int[] T)
        {
            int[] pom = new int[T.Length];
            for(int i =0;i<T.Length;i++)
            {
                if (CzyPierwsza(T[i])) pom[i] = T[i];
            }
            return pom;
        }
        static void Main(string[] args)
        {
            int[] T = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 1243, 71 };
            Console.WriteLine(DoMalych("BADEklrw"));
            Console.WriteLine(CzyJest1("badklrw"));
            Console.WriteLine(CzyJest2('a','b',"Adbklwacbdkb"));
            int[] w =ZwrocTablice(T);

        }
    }
}
