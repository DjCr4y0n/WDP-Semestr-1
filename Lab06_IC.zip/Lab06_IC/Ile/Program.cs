﻿using System;

namespace Ile
{
    class Program
    {
        static int Ile(int[] T1)
        {
            int i = 0;
            int licznik = 0;
            while (i + 1 < T1.Length)
            {
                if (T1[i]%3!=0 && T1[i+1]%3!=0)
                {
                    licznik += 1;
                }
                i += 1;
            }
            return licznik;
        }
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 2, 4, 5, 6, 7, 8 };
            Console.WriteLine(Ile(tab));
        }
    }
}
