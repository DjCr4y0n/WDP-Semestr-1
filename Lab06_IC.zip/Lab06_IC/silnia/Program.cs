﻿using System;

namespace silnia
{
    class Program
    {
        static int Liczenie(int n)
        {
            int wynik = 1;
            for(int i = n; n>0;n--)
            {
                wynik *= n;
            }
            return wynik;
        }
        static void Main(string[] args)
        {
            for (int i = 1; i < 10; i++)
            {

            
            Console.WriteLine(Liczenie(i));
            }
        }
    }
}
