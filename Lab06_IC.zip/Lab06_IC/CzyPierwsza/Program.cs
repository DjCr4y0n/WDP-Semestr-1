﻿using System;

namespace CzyPierwsza
{
    class Program
    {
        static bool CzyPierwsza(int a)
        {
            int dzielnik = 2;
            if (a != 1)
            {
                while (a > dzielnik)
                {
                    if (a % dzielnik == 0)
                    {
                        return false;
                    }


                    dzielnik += 1;
                }


                return true;

            }
            return false;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyPierwsza(2));
        }
    }
}
