﻿using System;

namespace Trojkat1
{
    class Program
    {
        static void WyswietlLinie(int ile) {
            int i = 0;
            while (i < ile)
            {
                Console.Write("*");
                ++i;
            }
            Console.WriteLine();
        }
        static void Trojkat1(int rozmiar)
        {
            int i = 1;
            while(i <= rozmiar)
            {
                WyswietlLinie(i);
                i += 1;
            }
        }
        static void Main(string[] args)
        {
            Trojkat1(5);
        }
    }
}
