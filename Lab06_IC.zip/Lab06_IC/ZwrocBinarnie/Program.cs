﻿using System;

namespace ZwrocBinarnie
{
    class Program
    {
        static string ZwrocBinarnie(long liczba)
        {
            string binarnie = "";
            while(liczba > 0)
            {
                binarnie += (liczba % 2).ToString();
                liczba = (liczba - (liczba % 2)) / 2;
            }
            string binarnie_odwrotnie = "";
            for (int i = binarnie.Length-1; i > -1 ; i--)
            {
                binarnie_odwrotnie += binarnie[i];
            }
            return binarnie_odwrotnie;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocBinarnie(8));
        }
    }
}
