﻿using System;

namespace OdwracanaieTablic
{
    class Program
    {
        static int[] Odwracanie1(int[] tab)
        {
            int[] pom = new int[tab.Length];
            for (int i=tab.Length-1; i>-1;i--)
            {
                pom[tab.Length - 1- i] = tab[i];  
            }
            return pom;
        }

        static int[] Odwracanie2(int[] tab)
        {
            for (int i = tab.Length - 1; i >= tab.Length/2; i--)
            {
                int p = tab[i];
                int q = tab[tab.Length - 1 - i];
                tab[tab.Length - 1 - i] = p;
                tab[i] = q;
            }
            return tab;

        }
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 3, 4, 5, 6, 7, 8 };
            int[] a = Odwracanie1(tab);
            int[] b = Odwracanie2(tab);
            for (int i=0;i<a.Length;i++)
            {
                Console.WriteLine(a[i]);
            }
            Console.WriteLine("");
            for (int i = 0; i < b.Length; i++)
            {
                Console.WriteLine(b[i]);
            }
        }
    }
}
