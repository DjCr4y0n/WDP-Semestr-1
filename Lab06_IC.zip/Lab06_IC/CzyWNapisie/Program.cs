﻿using System;

namespace CzyWNapisie
{
    class Program
    {
        static bool CzyWNapisie(string tekst, char znak)
        {
            int i = 0;
            while (i < tekst.Length && tekst[i] != znak)
            {
                i += 1;
            }
            return i < tekst.Length;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(CzyWNapisie("babajaga", 'a'));
        }
    }
}
