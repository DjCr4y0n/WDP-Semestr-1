﻿using System;

namespace SumaNieparzystych
{
    class Program
    {
        static long SumaNieparzystych(int[] T1)
        {
            int i = 0;
            int suma = 0;
            do
            {
                if (T1[i] % 2 != 0)
                {
                    suma += T1[i];
                }
                i += 1;
            } while (i < T1.Length);
            return suma;
        }
        static void Main(string[] args)
        {
            int[] tab = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            Console.WriteLine(SumaNieparzystych(tab));
        }
    }
}
