﻿using System;

namespace CzyJest
{
    class Program
    {
        static bool CzyJest(int[,] tablica, int liczba)
        {
            int i = 0;
            int x = 0;
            while (x < tablica.GetLength(0))
            {
                while (i < tablica.GetLength(1))
                {
                    if (tablica[x,i] == liczba)
                    {
                        return true;
                    }
                    i += 1;
                }
                x += 1;
            }
            return false;
        }
        static void Main(string[] args)
        {
            int[,] tab = { { 1, 2 }, { 3, 4 }, { 5, 6 } };
            Console.WriteLine(CzyJest(tab,4));
        }
    }
}
