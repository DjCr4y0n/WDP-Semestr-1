﻿using System;

namespace ProsteObliczenia
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("wynik obliczen" + Oblicz(10));
        }

        static int Oblicz(int x)
        { 
            return 2*x + 3;
        }
    }
}
