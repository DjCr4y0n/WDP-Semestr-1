﻿using System;

namespace ProstaFunkcja
{
    class Program
    {
        static void Main(string[] args)
        {
            Powitanie();
        }

        static void Powitanie()
        {
            Console.WriteLine("Witaj");
        }
    }
}
