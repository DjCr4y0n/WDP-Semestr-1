﻿using System;

namespace zad1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Igor Czarnoglowski- Moj pierwszy program na wstepie do programowania");
        }
    }
}
