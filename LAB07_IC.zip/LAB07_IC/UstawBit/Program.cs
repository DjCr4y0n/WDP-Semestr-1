﻿using System;

namespace UstawBit
{
    class Program
    {
        static uint UstawBit(uint stara_wartosc_rejestru, int ktory_bit, int wartosc)
        {
            uint maska;

            maska = 1u << ktory_bit;

            if (wartosc == 1)
                stara_wartosc_rejestru |= maska;
            else
                stara_wartosc_rejestru &= ~maska;

            return stara_wartosc_rejestru;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(UstawBit(10, 2, 1));
        }
    }
}
