﻿using System;

namespace IleJedynekItr
{
    class Program
    {
        static string ZwrocBinarnie(ulong liczba)
        {
            if (liczba == 0)
            {
                return "0";
            }
            string binarnie = "";
            for (int i = 0; i < 32 && liczba > 0; i++)
            {
                binarnie = (liczba & 1) + binarnie;
                liczba = liczba >> 1;
            }
            return binarnie;
        }
        static int IleJedynekItr(uint liczba)
        {
            int licznik = 0;
            string a = ZwrocBinarnie(liczba);
            for (int i =0; i<a.Length;i++)
            {
                if(a[i]=='1')
                {
                    licznik += 1;
                }
            }
            return licznik;
        }

        static int IleJedynekRek(uint liczba, int licznik = 0)
        {
            if(liczba==0)
            {
                return licznik;
            }
            string a = ZwrocBinarnie(liczba);
            if (a[^1] == '1')
            {
                return IleJedynekRek(liczba>>1, licznik + 1);
            }
            return IleJedynekRek(liczba >> 1,licznik);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(IleJedynekRek(19));
            Console.WriteLine(IleJedynekItr(5));
        }
    }
}
