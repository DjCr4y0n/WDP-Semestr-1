﻿using System;

namespace ZwrocLiczbeNaBitach_7_11
{
    class Program
    {
        static uint ZwrocLiczbeZBitow_7_11(uint rejestr)
        {
            rejestr >>= 7;
            return rejestr & 0x1F;
        }

        static uint TemperaturaWody(uint rejest)
        {
            return ZwrocLiczbeZBitow_7_11(rejest);
        }


        static void Main(string[] args)
        {
            Console.WriteLine(TemperaturaWody(999));
        }
    }
}
