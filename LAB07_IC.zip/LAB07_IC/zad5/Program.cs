﻿using System;

namespace zad5
{
    class Program
    {
        static uint Przemiana(uint rejestr)
        {
            rejestr >>= 13;
            return rejestr & 0x7FF;
        }
        static void Main(string[] args)
        {
           //do dokonczenia
        }
    }
}
