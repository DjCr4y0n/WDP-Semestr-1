﻿using System;

namespace ZwrocBinarnie
{
    class Program
    {
        static string ZwrocBinarnie(ulong liczba)
        {
            if(liczba == 0)
            {
                return "0";
            }
            string binarnie = "";
            for(int i = 0; i < 32 && liczba > 0; i++)
            {
                binarnie = (liczba & 1) + binarnie;
                liczba = liczba >> 1;
            }
            return binarnie;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(ZwrocBinarnie(0));
        }
    }
}
