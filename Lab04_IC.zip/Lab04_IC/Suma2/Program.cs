﻿using System;

namespace Suma2
{
    class Program
    {
        static uint Suma2(uint n)
        {
            if (n == 0) return 0;
            return n-1 + Suma2(n-1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Suma2(10));
        }
    }
}
