﻿using System;

namespace Suma1
{
    class Program
    {
        static ulong Suma1(uint n)
        {
            if (n==0)
            {
                return 0;
            }
            if (n==1)
            {
                return 1;
            }
            return n + Suma1(n - 1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Suma1(5));
        }
    }
}
