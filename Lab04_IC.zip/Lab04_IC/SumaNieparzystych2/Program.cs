﻿using System;

namespace SumaNieparzystych2
{
    class Program
    {
        static ulong SumaNieparzystych2(uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            ulong z_rek, tu;

            uint analizowana = n - 1;
            z_rek = SumaNieparzystych2(n - 1);
            if (analizowana % 2 != 0)
            {
                tu = analizowana;
            }
            else
            {
                tu = 0;
            }
            return z_rek + tu;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SumaNieparzystych2(5));
        }
    }
}
