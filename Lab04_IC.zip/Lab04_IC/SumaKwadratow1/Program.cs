﻿using System;

namespace SumaKwadratow1
{
    class Program
    {
        static ulong SumaKwadratow1(uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            return n * n + SumaKwadratow1(n - 1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SumaKwadratow1(5));
        }
    }
}
