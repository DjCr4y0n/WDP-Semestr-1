﻿using System;

namespace IleCyfr2
{
    class Program
    {
        static uint IleCyfr2(ulong liczba)
        {
            uint licznik = 0;
            if (liczba == 0) return licznik;
            if (liczba % 10 == 2) return IleCyfr2(liczba / 10) + 1;
            else return 0 + IleCyfr2(liczba / 10);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(IleCyfr2(12266229988222));
        }
    }
}
