﻿using System;

namespace SumaLiczb
{
    class Program
    {
        static ulong SumaLiczb(uint n)
        {
            if (n == 0) return 0;
            if ((n-1)%7!=0 && (n-1)%3==0)
            {
                return n - 1 + SumaLiczb(n - 1);
            }
            return SumaLiczb(n - 1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SumaLiczb(9));
        }
    }
}
