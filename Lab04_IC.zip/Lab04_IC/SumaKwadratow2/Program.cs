﻿using System;

namespace SumaKwadratow2
{
    class Program
    {
        static ulong SumaKwadratow2(uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            return (n - 1) * (n - 1) + SumaKwadratow2(n - 1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SumaKwadratow2(5));
        }
    }
}
