﻿using System;

namespace Fibonacci
{
    class Program
    {
        static ulong Fibonacci(uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            if (n == 1)
            {
                return 1;
            }
            return Fibonacci(n - 2) + Fibonacci(n - 1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(Fibonacci(5));
        }
    }
}
