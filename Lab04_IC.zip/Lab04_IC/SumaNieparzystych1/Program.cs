﻿using System;

namespace SumaNieparzystych1
{
    class Program
    {
        static ulong SumaNieparzystych1(uint n)
        {
            if (n == 0)
            {
                return 0;
            }
            if (n == 1)
            {
                return 1;
            }
            if (n % 2 != 0)
            {
                return n + SumaNieparzystych1(n - 1);
            }
            return SumaNieparzystych1(n-1);
        }
        static void Main(string[] args)
        {
            Console.WriteLine(SumaNieparzystych1(8));
        }
    }
}
