﻿using System;
using System.IO;

namespace Lista_jednokierunkowa
{
    class Lista
    {
        public class Węzeł
        {
            // w węźle przechowujemy "imię"
            public string imię;
            public Węzeł następny;
        }

        public Węzeł głowa;

        public bool CzyPusta()
        {
            return głowa == null;
        }

        public int ZwróćRozmiar()
        {
            int licznik = 0;
            for (Węzeł aktualny = głowa; aktualny != null; aktualny = aktualny.następny)
            {
                licznik++;
            }
            return licznik;
        }
        public void DodajDoGłowy(string imię)
        {
            Węzeł nowy = new Węzeł();
            nowy.imię = imię;
            // dodany element staje się głową, więc dotychczasowa głowa staje się obiektem, który jest "następny"
            nowy.następny = głowa;
            // dodany element staje się głową
            głowa = nowy;
        }

        public string UsuńZGłowy()
        {
            string dane;
            if (głowa != null) // sprawdzamy, czy lista nie jest pusta
            {
                dane = głowa.imię;
                głowa = głowa.następny;
                return dane;
            }
            else
                throw new Exception("Lista pusta!");
        }
        public void Wyświetl()
        {
            if (głowa == null)
            {
                Console.WriteLine("Lista jest pusta");
                return;
            }
            Węzeł w = głowa;
            while(w!=null)
            {
                Console.WriteLine(w.imię);
                w = w.następny;
            }
        }
        public void ZapiszWęzeł(StreamWriter sw, Węzeł w)
        {
            sw.WriteLine(w.następny);
        }
        public Węzeł OdczytajWęzeł(StreamReader sr)
        {
            
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Lista mojaLista = new Lista();
            StreamWriter sw = new StreamWriter("plik.txt");

            mojaLista.DodajDoGłowy("Ola");
            mojaLista.DodajDoGłowy("Ada");
            mojaLista.DodajDoGłowy("Ula");
            mojaLista.DodajDoGłowy("Ala");
            mojaLista.Wyświetl();

            Console.WriteLine("Liczba elementów na liście " + mojaLista.ZwróćRozmiar());

            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine("Usuwam: " + mojaLista.UsuńZGłowy());
            }
            mojaLista.Wyświetl();
            
        }
    }
}

