﻿using System;
using System.IO;
using System.Text;


namespace Student
{
    class Program
    {
        class Student
        {
            public string imię;
            public string nazwisko;
            public int rokUrodzenia;
            public double ocena;
            // konstruktor struktury
            // należy zainicjalizować wszystkie pola struktury
            public Student()
            {
                imię = "";
                nazwisko = ""; // this - odwołanie do pola struktury
                rokUrodzenia = 0;
                ocena = 0;
            }
            // niestatyczne metody struktury
            public string ZwróćInformacje()
            {
                return imię + " " + nazwisko + " " + rokUrodzenia + " " + ocena;
            }
            public void Edytuj(string imie, string nazwisko, int rokUrodzenia, int ocena)
            {
                this.imię = imie;
                this.nazwisko = nazwisko;
                this.rokUrodzenia = rokUrodzenia;
                this.ocena = ocena;
            }
        }

        class Uczelnia

        {

            // na uczelni będzie wiele wydziałów

            public Wydział[] wydzialy;

            public int licznikWydziałów;

        }



        class Wydział

        {

            // na wydziale będzie wiele roczników studentów

            public RocznikStudentów[] roczniki;

            public int licznikRoczników;

        }

        class RocznikStudentów

        {

            // tablica studentów

            public Student[] studenci;

            // liczy, ile studentów jest na roczniku

            public int licznik;



            // konstruktor - inicjalizuje wszystkie pola

            public RocznikStudentów(Student[] studenci)

            {

                this.studenci = studenci;

                licznik = studenci.Length; //0

            }



            public RocznikStudentów(int rozmiar)

            {

                studenci = new Student[rozmiar];

                licznik = 0;

            }

            // dodaje studenta do rocznika

            public void DodajDoRocznika(Student o)

            {

                // jeśli w tablicy jest jeszcze miejsce, dodajemy studenta

                if (licznik < studenci.Length)

                {

                    studenci[licznik] = o;

                    licznik++;

                }

                else

                {

                    // jeśli tablica jest wypełniona, należy zwiększyć rozmiar

                    // tworzymy nową tablicę o większym rozmiarze

                    Student[] tab = new Student[studenci.Length + 1];

                    // kopiujemy dane do nowej tablicy

                    for (int i = 0; i < studenci.Length; i++)

                    {

                        tab[i] = studenci[i];

                    }

                    // ustawiamy referencję studenci na nową tablicę

                    studenci = tab;

                    // i dodajemy studenta do zwiększonej tablicy

                    studenci[licznik] = o;

                    licznik++;

                }

            }

            public void UsuńZRocznika(int doUsuniecia)

            {

                if (doUsuniecia < licznik && doUsuniecia >= 0)

                {

                    // usunięcie polega na przesunięciu wszystkich elementów "za" usuwanym elementem o jedną pozycję wyżej

                    for (int i = doUsuniecia; i < this.licznik - 1; i++)

                    {

                        studenci[i] = studenci[i + 1];

                    }

                    licznik--;

                }

            }

            public string ZwróćInformacje()

            {

                string text = "";

                // zwraca wszystkie elementy tablicy

                for (int i = 0; i < licznik; i++)

                {

                    text += "" + (i + 1) + " " + studenci[i].ZwróćInformacje() + "\n";

                }

                return text;

            }

        }
        static void Main(string[] args)
        {
            Student s1 = new Student();
            s1.imię = "igor";
            s1.nazwisko = "Czarnoglwoski";
            s1.rokUrodzenia = 2005;
            Console.WriteLine(ZwrocStudenta(s1));
        }

        static string ZwrocStudenta(Student s)
        {
            return ($"{s.imię} {s.nazwisko} {s.rokUrodzenia} {s.ocena}");
        }

        static void ZapiszStudenta(Student s, StreamWriter sw)
        {
            sw = new StreamWriter("Testowy.txt");
            sw.WriteLine(ZwrocStudenta(s));
        }

        static Student OdczytajStudenta(StreamReader sr)
        {
            sr = new StreamReader("Testowy.txt");
            string linia = sr.ReadLine();
            Student s2 = new Student();
            string[] tab = { };
            string wyraz = "";
            int k = 0;
            foreach (char c in linia)
            {
                if(char.IsLetter(c))
                {
                    wyraz += c;
                }
                else
                {
                    tab[k] = wyraz; 
                    wyraz = "";
                    k += 1;
                }
            }
            s2.imię = tab[0];
            s2.nazwisko = tab[1];
            s2.rokUrodzenia = Convert.ToInt32(tab[2]);
            s2.ocena = Convert.ToInt32(tab[3]);
            return s2;
        }

        static RocznikStudentów OdczytajRocznik(string nazwapliku, int ileStudentow)
        {
            StreamReader sr = new StreamReader(nazwapliku);
            RocznikStudentów s1 = new RocznikStudentów(ileStudentow);
            return s1;
        }

        static void Konwertuj(string wejscie, string wyjscie)
        {

        }

    }
}
